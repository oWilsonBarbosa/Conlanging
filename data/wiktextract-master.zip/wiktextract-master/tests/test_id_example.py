from unittest import TestCase

from wikitextprocessor import Wtp

from wiktextract.config import WiktionaryConfig
from wiktextract.extractor.id.page import parse_page
from wiktextract.wxr_context import WiktextractContext


class TestIdExample(TestCase):
    maxDiff = None

    def setUp(self) -> None:
        self.wxr = WiktextractContext(
            Wtp(lang_code="id"),
            WiktionaryConfig(
                dump_file_lang_code="id", capture_language_codes=None
            ),
        )

    def tearDown(self):
        self.wxr.wtp.close_db_conn()

    def test_example_list(self):
        self.wxr.wtp.add_page("Templat:bhs", 10, "bahasa Indonesia")
        page_data = parse_page(
            self.wxr,
            "cinta",
            """==bahasa Palembang==
===Verba===
# [[tambah]]
#: ''payo '''bubuh''' pempeknyo, jangan semon-semon''
#:: ayo '''tambah''' pempeknya, jangan malu-malu""",
        )
        self.assertEqual(
            page_data[0]["senses"],
            [
                {
                    "examples": [
                        {
                            "text": "payo bubuh pempeknyo, jangan semon-semon",
                            "bold_text_offsets": [(5, 10)],
                            "translation": "ayo tambah pempeknya, jangan malu-malu",
                            "bold_translation_offsets": [(4, 10)],
                        }
                    ],
                    "glosses": ["tambah"],
                }
            ],
        )

    def test_italic_after_br(self):
        page_data = parse_page(
            self.wxr,
            "angin",
            """==bahasa Indonesia==
===Nomina===
# hawa; udara: <br />''ban berisi angin''""",
        )
        self.assertEqual(
            page_data[0]["senses"],
            [
                {
                    "glosses": ["hawa; udara:"],
                    "examples": [{"text": "ban berisi angin"}],
                }
            ],
        )

    def test_obsolete_list(self):
        page_data = parse_page(
            self.wxr,
            "I",
            """==bahasa Inggris==
===Pronomina===
# [[saya]] (formal)
#: '''''I''' am Australian''
#:: '''''saya''' orang Australi''
#:: '''''saya''' orang Australia''""",
        )
        self.assertEqual(
            page_data[0]["senses"],
            [
                {
                    "glosses": ["saya (formal)"],
                    "examples": [
                        {
                            "text": "I am Australian",
                            "bold_text_offsets": [(0, 1)],
                            "translation": "saya orang Australi",
                            "bold_translation_offsets": [(0, 4)],
                        },
                        {
                            "text": "I am Australian",
                            "bold_text_offsets": [(0, 1)],
                            "translation": "saya orang Australia",
                            "bold_translation_offsets": [(0, 4)],
                        },
                    ],
                }
            ],
        )
