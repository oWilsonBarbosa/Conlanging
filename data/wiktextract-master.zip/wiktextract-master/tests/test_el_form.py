from unittest import TestCase

from wikitextprocessor import Wtp

from wiktextract.config import WiktionaryConfig
from wiktextract.extractor.el.models import Form
from wiktextract.extractor.el.parse_utils import expand_suffix_forms
from wiktextract.extractor.el.table import postprocess_table_forms
from wiktextract.wxr_context import WiktextractContext


class TestElInflection(TestCase):
    maxDiff = None

    def setUp(self) -> None:
        self.wxr = WiktextractContext(
            Wtp(lang_code="el"),
            WiktionaryConfig(
                dump_file_lang_code="el",
                capture_language_codes=None,
            ),
        )

    def tearDown(self) -> None:
        self.wxr.wtp.close_db_conn()

    def mktest_postprocess_table_forms(
        self, raw: str, expected: list[str], word: str = "filler"
    ) -> None:
        forms = [Form(form=entry.strip()) for entry in raw.splitlines()]
        new_forms = postprocess_table_forms(forms, word)
        new_forms_lemmas = [form.form for form in new_forms]
        self.assertEqual(new_forms_lemmas, expected)

    def test_postprocess_forms_separators1(self) -> None:
        # https://el.wiktionary.org/wiki/τρώω
        raw = "έτρωγαν / τρώγανε"
        expected = ["έτρωγαν", "τρώγανε"]
        self.mktest_postprocess_table_forms(raw, expected)

    def test_postprocess_forms_separators2(self) -> None:
        # https://el.wiktionary.org/wiki/ζητάω
        raw = "να ζητάν(ε) - ζητούν(ε)"
        expected = ["να ζητάν", "να ζητάνε", "να ζητούν", "να ζητούνε"]
        self.mktest_postprocess_table_forms(raw, expected)

    def test_postprocess_forms_separators3(self) -> None:
        # https://el.wiktionary.org/wiki/ζητάω
        raw = "ζητούσαν(ε) - ζήταγαν - ζητάγανε"
        expected = ["ζητούσαν", "ζητούσανε", "ζήταγαν", "ζητάγανε"]
        self.mktest_postprocess_table_forms(raw, expected)

    def test_postprocess_forms_remove_articles1(self) -> None:
        # https://el.wiktionary.org/wiki/λίθος
        # raw = "του/της λίθου" < This is never parsed by us
        # expected = ["λίθου"]  <
        raw = """
        ο/η
        του/της
        τον/τη
        τους/τις
        """.strip()
        self.mktest_postprocess_table_forms(raw, [])

    def test_postprocess_forms_remove_articles2(self) -> None:
        # https://el.wiktionary.org/wiki/ανθυποπλοίαρχος
        raw = "τον/την"
        self.mktest_postprocess_table_forms(raw, [])

    def test_postprocess_forms_suffix(self) -> None:
        # https://el.wiktionary.org/wiki/-ισμός
        word = "-ισμός"
        raw = "ο -ισμός"
        expected = ["-ισμός"]
        self.mktest_postprocess_table_forms(raw, expected, word)

    def test_postprocess_forms_hyphenated_word(self) -> None:
        # https://el.wiktionary.org/wiki/η-τάξη
        word = "η-τάξη"
        raw = "η η-τάξη"
        expected = ["η-τάξη"]
        self.mktest_postprocess_table_forms(raw, expected, word)

    def test_postprocess_forms_trailing_numbers(self) -> None:
        # https://el.wiktionary.org/wiki/Καπιτόπουλος
        raw = "Καπιτοπουλαίοι1"
        expected = ["Καπιτοπουλαίοι"]
        self.mktest_postprocess_table_forms(raw, expected)

    def mktest_expand_suffix_forms(self, raw: str, expected: list[str]) -> None:
        forms = [Form(form=entry.strip()) for entry in raw.split(",")]
        new_forms = expand_suffix_forms(forms)
        new_forms_lemmas = [form.form for form in new_forms]
        self.assertEqual(new_forms_lemmas, expected)

    def test_expand_suffix_forms_adj1(self) -> None:
        # https://el.wiktionary.org/wiki/άμεσος
        raw = "άμεσος, -η, -ο"
        expected = ["άμεσος", "άμεση", "άμεσο"]
        self.mktest_expand_suffix_forms(raw, expected)

    def test_expand_suffix_forms_adj2(self) -> None:
        # https://el.wiktionary.org/wiki/αρσενικός
        raw = "αρσενικός, -ή/-ιά, -ό"
        expected = ["αρσενικός", "αρσενική", "αρσενικιά", "αρσενικό"]
        self.mktest_expand_suffix_forms(raw, expected)

    def test_expand_suffix_forms_adj3(self) -> None:
        # https://el.wiktionary.org/wiki/σιδηρούς
        raw = "σιδηρούς, -ά, -ούν "
        expected = ["σιδηρούς", "σιδηρά", "σιδηρούν"]
        self.mktest_expand_suffix_forms(raw, expected)

    def test_expand_suffix_forms_adj4(self) -> None:
        # https://el.wiktionary.org/wiki/εξαμηνιαίος
        raw = "εξαμηνιαίος, -α, -ο"
        expected = ["εξαμηνιαίος", "εξαμηνιαία", "εξαμηνιαίο"]
        self.mktest_expand_suffix_forms(raw, expected)

    def test_expand_suffix_forms_participle(self) -> None:
        # https://el.wiktionary.org/wiki/αναμμένος
        raw = "αναμμένος, -η, -ο"
        expected = ["αναμμένος", "αναμμένη", "αναμμένο"]
        self.mktest_expand_suffix_forms(raw, expected)

    def test_expand_already_expanded(self) -> None:
        # https://el.wiktionary.org/wiki/πολύς
        raw = "πολύς, πολλή, πολύ"
        expected = ["πολύς", "πολλή", "πολύ"]
        self.mktest_expand_suffix_forms(raw, expected)
