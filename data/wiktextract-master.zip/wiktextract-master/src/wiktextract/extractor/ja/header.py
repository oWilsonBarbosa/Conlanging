import re

from wikitextprocessor.parser import HTMLNode, NodeKind, TemplateNode, WikiNode

from ...page import clean_node
from ...wxr_context import WiktextractContext
from .models import Classifier, Form, WordEntry
from .tags import translate_raw_tags

FORM_OF_CLASS_TAGS = frozenset(["kanji", "plural"])


def extract_header_nodes(
    wxr: WiktextractContext, word_entry: WordEntry, nodes: list[WikiNode]
) -> None:
    extracted_forms = {}
    use_nodes = []
    is_first_bold = True
    for node in nodes:
        if isinstance(node, TemplateNode) and node.template_name in (
            "jachar",
            "kochar",
            "vichar",
            "zhchar",
        ):
            is_first_bold = False
        elif isinstance(node, TemplateNode):
            if node.template_name.startswith(word_entry.lang_code + "-"):
                use_nodes.append(node)
            # ignore other templates, like "wikipedia" and "commonscat"
        else:
            use_nodes.append(node)
    expanded_nodes = wxr.wtp.parse(
        wxr.wtp.node_to_wikitext(use_nodes), expand_all=True
    )
    raw_tags = []
    for node in expanded_nodes.find_child_recursively(
        NodeKind.HTML | NodeKind.BOLD | NodeKind.ITALIC
    ):
        if (
            isinstance(node, HTMLNode)
            and "gender" in node.attrs.get("class", "").split()
        ):
            raw_tag_text = clean_node(wxr, None, node)
            for raw_tag in re.split(r"\s|,", raw_tag_text):
                raw_tag = raw_tag.strip()
                if raw_tag != "":
                    word_entry.raw_tags.append(raw_tag)
        if isinstance(node, HTMLNode) and not (
            node.tag in ["strong", "small", "i", "b"]
            or "headword" in node.attrs.get("class", "")
            or "form-of" in node.attrs.get("class", "")
        ):
            continue
        if (isinstance(node, HTMLNode) and node.tag in ["small", "i"]) or (
            isinstance(node, WikiNode) and node.kind == NodeKind.ITALIC
        ):
            raw_tag = clean_node(wxr, None, node).strip("(): ")
            if raw_tag not in raw_tags:
                raw_tags.append(raw_tag)
        elif (
            isinstance(node, HTMLNode)
            and node.tag == "span"
            and "form-of" in node.attrs.get("class", "").split()
        ):
            for span_child in node.children:
                if isinstance(span_child, str) and span_child.strip() != "":
                    raw_tags.append(span_child.strip())
                elif (
                    isinstance(span_child, WikiNode)
                    and span_child.kind == NodeKind.BOLD
                ):
                    word = clean_node(wxr, None, span_child)
                    if word != "":
                        add_form_data(
                            node, word, extracted_forms, word_entry, raw_tags
                        )
                    raw_tags.clear()
        else:
            form_text = clean_node(wxr, None, node).strip("（）【】 ")
            add_form_data(
                node,
                form_text,
                extracted_forms,
                word_entry,
                raw_tags,
                is_canonical=is_first_bold,
            )
            if node.kind == NodeKind.BOLD:
                is_first_bold = False
            raw_tags.clear()
    new_forms = []
    for form in word_entry.forms:
        if "類別詞" in form.raw_tags:
            word_entry.classifiers.append(
                Classifier(
                    classifier=form.form, tags=form.tags, raw_tags=form.raw_tags
                )
            )
        else:
            new_forms.append(form)
    word_entry.forms = new_forms
    clean_node(wxr, word_entry, expanded_nodes)
    if len(raw_tags) > 0:
        word_entry.raw_tags.extend(raw_tags)
    for category in word_entry.categories:
        if category.endswith("定形"):
            # Needs to be tags and no raw_tags because of pos::find_form_of_data
            word_entry.tags.append("form-of")
    translate_raw_tags(word_entry)


def add_form_data(
    node: WikiNode,
    forms_text: str,
    extracted_forms: dict[str, Form],
    word_entry: WordEntry,
    raw_tags: list[str],
    is_canonical: bool = False,
) -> None:
    for form_text in re.split(r"・|、|,|•", forms_text):
        form_text = form_text.strip()
        if form_text in extracted_forms:
            form = extracted_forms[form_text]
            for raw_tag in raw_tags:
                if raw_tag not in form.raw_tags:
                    form.raw_tags.append(raw_tag)
            translate_raw_tags(form)
            continue
        elif (
            form_text == word_entry.word
            or form_text.replace(" ", "") == word_entry.word
            or len(form_text) == 0
        ):
            continue
        form = Form(
            form=form_text, raw_tags=raw_tags if raw_tags != ["又は"] else []
        )
        extracted_forms[form_text] = form
        if (
            node.kind == NodeKind.BOLD
            or (isinstance(node, HTMLNode) and node.tag == "strong")
        ) and is_canonical:
            form.tags.append("canonical")
            is_canonical = False
        if isinstance(node, HTMLNode):
            class_names = node.attrs.get("class", "")
            for class_name in FORM_OF_CLASS_TAGS:
                if class_name in class_names:
                    form.tags.append(class_name)
        class_name = node.attrs.get("class", "")
        if "tr Latn" in class_name or "headword-tr" in class_name:
            form.tags.append("transliteration")
        translate_raw_tags(form)
        if raw_tags == ["又は"] and len(word_entry.forms) > 0:
            form.tags = word_entry.forms[-1].tags
            form.raw_tags = word_entry.forms[-1].raw_tags
        word_entry.forms.append(form)
