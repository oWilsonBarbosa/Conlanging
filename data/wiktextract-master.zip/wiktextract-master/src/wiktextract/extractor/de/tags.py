from .models import WordEntry

# Sense tags
# https://de.wiktionary.org/wiki/Vorlage:K
# https://de.wiktionary.org/wiki/Vorlage:K/Abk
K_TEMPLATE_TAGS = {
    "Abl.": "ablative",
    "Ablativ": "ablative",
    "abw.": "derogatory",
    "abwertend": "derogatory",
    "AE": "US",
    "AmE": "US",
    "adv.": "adverbial",
    "Akkusativ": "accusative",
    "alemann.": "Alemannic",
    "alemannisch": "Alemannic",
    "allg.": "general",
    "allgemein": "general",
    "alltagsspr.": "colloquial",
    "amtsspr.": "officialese",
    # "ansonsten": "otherwise",  # combined with other text
    "attr.": "attributive",
    # "auch": "also",
    "bair.": "Bavarian",
    "bairisch": "Bavarian",
    "bar.": "Bavarian",
    "direktional": "directional",
    "BE": "British",
    "BrE": "British",
    "Bedva.": "outdated",
    "Bedvatd.": "outdated",
    "besonders": "especially",
    "veraltende Bedeutung": "outdated",
    # "bei": "",
    # "bes.": "especially",
    # "besonders": "especially",
    # "beziehungsweise": "",
    # "bzw.": "",
    # "bildungsspr.": "",
    # "bis": "",
    # "bisweilen": "",
    # "das": "",
    "Dativ": "dative",
    # "DDR": "",
    "Deutschland": "Germany",
    # "der": "",
    "dichter.": "poetic",
    "dichterisch": "poetic",
    # "die": "",
    "Dim.": "diminutive",
    "Dimin.": "diminutive",
    "Diminutiv": "diminutive",
    # "eher": "",
    "erzg.": "Erzgebirgisch",
    "erzgeb.": "Erzgebirgisch",
    "erzgebirgisch": "Erzgebirgisch",
    "euph.": "euphemistic",
    "fachspr.": "jargon",
    "fachsprachlich": "jargon",
    "fam.": "familiär",
    "fig": "figurative",
    "fig.": "figurative",
    # "früher": "",
    # "gegenwartslateinisch": "",
    "geh.": "gehoben",
    "Genitiv": "genitive",
    "gsm": "Swiss German",
    "häufig": "often",
    "haben": "auxiliary",
    "hebben": "auxiliary",
    "hauptsächlich": "primarily",
    "hist.": "historical",
    "ieS": "narrowly",
    "i.e.S.": "narrowly",
    "i. e. S.": "narrowly",
    # "im": "",
    # "in": "",
    # "in Bezug auf": "relational",
    "indekl.": "indeclinable",
    # "insbes.": "",
    "Instrumental": "instrumental",
    "intrans.": "intransitive",
    "intransitiv": "intransitive",
    # "iPl": "in plural",
    "iron.": "ironic",
    # "iwS": "",
    # "jugendspr.": "",
    "kinderspr.": "childish",
    "kirchenlateinisch": "Church Latin",
    "klasslat.": "Classical Latin",
    "klassischlateinisch": "Classical Latin",
    "kPl.": "no-plural",
    "kein Plural": "no-plural",
    "kSg.": "no-singulative",
    "kSt.": "no-comparative",
    "kurz für": "short-form",
    "landsch.": "regional",
    "landschaftlich": "regional",
    "lautm.": "onomatopoeic",
    "lokal": "regional",
    "Ling.": "linguistics",
    "mA": "accusative",
    "md.": "Central German",
    "mdal.": "dialectal",
    "Med.": "medicine",  # topic
    # "meist": "mostly",
    # "meistens": "mostly",
    "metaphor.": "metaphoric",
    "meton.": "metonymically",
    "mG": "genitive",
    "mitteld.": "Central German",
    "mit Dativ": "with-dative",
    "mit Akkusativ": "with-accusative",
    # "mitunter": "",
    "mlat.": "Medieval Latin",
    "mittellateinisch": "Medieval Latin",
    "mundartl.": "dialectal",
    "nDu.": "only-dual",
    "nigr.": "Niger",
    "nigrisch": "Niger",
    "nkLat.": "post-Classical Latin",
    "nachklassischlateinisch": "post-Classical Latin",
    "nlat.": "New Latin",
    "neulateinisch": "New Latin",
    "nordd.": "North German",
    "norddeutsch": "North German",
    "nordwestd.": "Northwestern Germany",
    "nPl.": "plural-only",
    "Österreich": "Austrian German",
    "örtlich": "regional",
    "österr.": "Austrian German",
    "österreichisch": "Austrian German",
    "ostfränkisch": "East Franconian German",
    "pej.": "pejorative",
    "personifizierend": "person",
    "poet.": "poetic",
    "PräpmG": "genitive prepositional",
    "PmG": "genitive prepositional",
    "reg.": "regional",
    "refl.": "reflexive",
    "reflexiv": "reflexive",
    # "respektive": "",
    "sal.": "casual",
    "salopp": "casual",
    "scherzh.": "jocular",
    "schriftspr.": "literary",
    # "schülerspr.": "",
    "schwäb.": "Swabian",
    "schwäbisch": "Swabian",
    "Schweiz": "Swiss Standard German",
    "schweiz.": "Swiss Standard German",
    "schweizerisch": "Swiss Standard German",
    "Schweizerdeutsch": "Swiss German",
    "schweizerdeutsch": "Swiss German",
    # "seemannsspr.": "",
    "sein": "auxiliary verb",
    # "sehr": "",  # very
    "selten": "rare",
    "seltener": "rare",
    "seltener auch": "rare",
    "soldatenspr.": ["military", "slang"],
    # "sonderspr.": "",
    # "sonst": "",
    # "sowie": "",
    "spätlat.": "Late Latin",
    "spätlateinisch": "Late Latin",
    # "später": "",
    "speziell": "special",
    "südd.": "South German",
    "süddt.": "South German",
    # "techn.": "",
    # "teils": "",
    # "teilweise": "",
    "temporal": "temporal",
    "tlwva.": "outdated",
    "tlwvatd.": "outdated",
    "trans.": "transitive",
    "transitiv": "transitive",
    # "über": "",
    # "überwiegend": "mostly",
    "übertr.": "figurative",
    "übertragen": "figurative",
    "ugs.": "colloquial",
    "umgangssprachlich": "colloquial",
    # "und": "",
    "ungebr.": "uncommon",
    "unpers.": "impersonal",
    "unpersönlich": "impersonal",
    # "ursprünglich": "",
    "va.": "outdated",
    "vatd.": "outdated",
    "veraltend": "outdated",
    # "verh.": "",
    "volkst.": "popular",
    # "von": "",
    # "vor allem": "",
    # "vor allem in": "",
    "vul.": "vulgar",
    "vulg.": "vulgar",
    "vlat.": ["vulgar", "Latin"],
    "vulgärlat": ["vulgar", "Latin"],
    "vulgärlateinisch": ["vulgar", "Latin"],
    "wien.": "Vienna",
    "wienerisch": "Vienna",
    "Wpräp": "prepositional",
    # "z. B.": "",
    # "z. T.": "",
    # "zijn": "",
    # "zum Beispiel": "",
    # "zum Teil": "",
    # "zumeist": "",
    "Kardinalzahl": "cardinal",
    "Sammelbegriff": "collective",
    "Fachsprache": "jargon",
    "formale Sprachen": "formal",
    "Programmiersprachen": "programming",
    "Rechnerarchitektur": "programming",
    "Geografie": "geography",
    "Geometrie": "geometry",
    "Finanzwesen": "finance",
    "juristisch": "law",
    "Physik": "physics",
    "abstrakt": "abstract",
    "gegenständlich": "objective",
    "personifiziert": "personal",
    "kirchlich": "Ecclesiastical",
}

GENDER_TAGS = {
    "n": "neuter",
    "m": "masculine",
    "f": "feminine",
    "u": "common",
    "m, f": ["masculine", "feminine"],  # Vorlage:mf
    "m, f, n": ["masculine", "feminine", "neuter"],  # Vorlage:mfn
    "f, n": ["feminine", "neuter"],  # Vorlage:fn
    # Vorlage:Deklinationsseite Adjektiv
    "Maskulinum": "masculine",
    "Femininum": "feminine",
    "Neutrum": "neuter",
    "f Pl.": ["feminine", "plural"],  # Template:fPl.
    "m Pl.": ["masculine", "plural"],  # Template:mPl.
    "n Pl.": ["neuter", "plural"],  # Template:nPl.
    "u Pl.": ["common", "plural"],  # Template:uPl.
}

NUMBER_TAGS = {
    # Vorlage:Deutsch Substantiv Übersicht
    "Singular": "singular",
    "Plural": "plural",
    "Pl.": "plural",
    "pl": "plural",
    "Dual": "dual",
    "ohne Plural": "no-plural",
    "meist im Plural": "plural-normally",
    "meist Plural": "plural-normally",
    "nur Plural": "plural-only",
}

CASE_TAGS = {
    # Vorlage:Deutsch Substantiv Übersicht
    "Nominativ": "nominative",
    "Genitiv": "genitive",
    "Dativ": "dative",
    "Akkusativ": "accusative",
    # Template:Polnisch Substantiv Übersicht
    "Lokativ": "locative",
    "Vokativ": "vocative",
    "Dativ Singular": ["dative", "singular"],
    "Genitiv Singular": ["genitive", "singular"],
    # Template:Finnisch Substantiv Übersicht
    "Inessiv": "inessive",
    "Elativ": "elative",
    "Illativ": "illative",
    "Adessiv": "adessive",
    "Allativ": "allative",
    "Essiv": "essive",
    "Translativ": "translative",
    "Abessiv": "abessive",
    "Instruktiv": "instructive",
    "Komitativ": "comitative",
    "Partitiv": "partitive",
}

COMPARISON_TAGS = {
    # Vorlage:Deutsch Adjektiv Übersicht
    # Vorlage:Deklinationsseite Adjektiv
    "Positiv": "positive",
    "Komparativ": "comparative",
    "Superlativ": "superlative",
}

DECLENSION_TAGS = {
    # https://en.wikipedia.org/wiki/German_declension
    # Vorlage:Deklinationsseite Adjektiv
    "Starke Deklination": "strong",
    "Schwache Deklination": "weak",
    "Gemischte Deklination": "mixed",
}

OTHER_TAGS = {
    # Vorlage:Deklinationsseite Adjektiv
    "Prädikativ": "predicative",
    "erweiterte": "extended",
    "Höflichkeitsform": "honorific",
    # Vorlage:Deutsch Verb schwach untrennbar reflexiv
    "nichterweitert": "not-extended",
    "erweitert": "extended",
    "zeitlich": "temporal",
    "indeklinabel": "indeclinable",
    "östlich": "Eastern",
    "westlich": "Western",
    "britisch": "British",
    "Substantive": "noun",
    "Substantiv": "noun",
    "historisch": "historical",
    "wörtlich": "literally",
    "Adjektiv": "adjective",
    "gehoben": "literary",
    "Nebenform von": "variant",
    "Verben": "verb",
    "regional": "regional",
    # Vorlage:CH&LI
    "Schweiz und Liechtenstein": ["Switzerland", "Liechtenstein"],
    "Switzerland and Liechtenstein": ["Switzerland", "Liechtenstein"],
    "traditionell": "traditional",
    "vereinfachte Schreibweise": "simplified",
    "US-amerikanisch": "US",
    "Adjektive": "adjective",
    "australisch": "Australian",
    "scherzhaft": "humorous",
    "Minuskel": "lowercase",
    "Majuskel": "uppercase",
    "bildungssprachlich": "formal",
    "Imperativ Singular": ["imperative", "singular"],
    "meist": "usually",
    "deutsch": "German",
    "pariserisch": "Parisian",
    "derb": "impolite",
    "poetisch": "poetic",
    "Adverb": "adverb",
    "süddeutsch": "South-German",
    "Verb": "verb",
    "kanadisch": "Canadian",
    "Supinum": "supine",
    "Kanada": "Canada",
    "vulgär": "vulgar",
    "metonymisch": "metonymically",
    "veraltet": "dated",
    "kolumbianisch": "Colombian",
    "Medial": "medial",
    "Pinyin": "Pinyin",
    "Wade-Giles": "Wade-Giles",
    "umgangssprachlich": "colloquial",
    "literarisch": "literary",
    "franz.": "French",
    "engl.": "English",
}

TENSE_TAGS = {
    # Vorlage:Deutsch Verb Übersicht
    "Präsens": "present",
    "Präteritum": "past",
    "Perfekt": "perfect",
    "Futur I": "future-i",
    "Futur II": "future-ii",
    "Plusquamperfekt": "pluperfect",
    # Template:Kroatisch Verb Übersicht
    "perfektiv": "perfective",
    "imperfektiv": "imperfective",
    "Imperfekt": "imperfect",
    "Futur": "future",
}

MOOD_TAGS = {
    # Vorlage:Deutsch Verb Übersicht
    # Vorlage:Deutsch Verb regelmäßig
    "Konjunktiv I": "subjunctive-i",
    "Konjunktiv II": "subjunctive-ii",
    "Imperativ": "imperative",
    "Imperative": "imperative",
    "Indikativ": "indicative",
    # Template:Schwedisch Verb Übersicht
    "Konjunktiv": "subjunctive",
    "Konditional": "conditional",
    # Template:Englisch Verb Übersicht
    "simple present": "present",
    "simple past": "past",
    "present participle": ["present", "participle"],
    "past participle": ["past", "participle"],
}

VERB_FORM_TAGS = {
    # Vorlage:Deutsch Verb Übersicht
    "Partizip II": "participle-2",
    "Hilfsverb": "auxiliary",
    "Infinitive": "infinitive",
    "Infinitiv": "infinitive",
    "Partizipien": "participle",
    "unregelmäßig": "irregular",
    "Aorist": "aorist",
    # Template:Dänisch Verb Übersicht
    "Partizip Perfekt": ["participle", "perfect"],
}

VOICE_TAGS = {
    # Vorlage:Deutsch Verb unregelmäßig
    "Aktiv": "active",
    "Vorgangspassiv": "processual-passive",
    "Zustandspassiv": "statal-passive",
    "Passiv": "passive",
    "Gerundivum": "gerundive",
    # Vorlage:Deutsch Verb schwach untrennbar reflexiv
    "Zustandsreflexiv": "statal-reflexive",
}

PERSON_TAGS = {
    # Vorlage:Deutsch Verb unregelmäßig
    "1. Person Singular": ["first-person", "singular"],
    "1. Person Plural": ["first-person", "plural"],
    "2. Person Singular": ["second-person", "singular"],
    "2. Person Plural": ["second-person", "plural"],
    "3. Person Singular": ["third-person", "singular"],
    "3. Person Plural": ["third-person", "plural"],
    # Vorlage:Deutsch Verb schwach untrennbar reflexiv
    "Sg. 1. Pers.": ["first-person", "singular"],
    "Pl. 1. Pers.": ["first-person", "plural"],
    "Sg. 2. Pers.": ["second-person", "singular"],
    "Pl. 2. Pers.": ["second-person", "plural"],
    "Sg. 3. Pers.": ["third-person", "singular"],
    "Pl. 3. Pers.": ["third-person", "plural"],
}

INFLECTION_TABLE_TAGS = {
    # Vorlage:Deutsch Verb regelmäßig
    "ungebräuchlich": "uncommon",
    "veraltet": "archaic",
    # Vorlage:Deutsch Verb schwach trennbar reflexiv
    "Nebensatzkonjugation": "subordinate-clause",
    "Hauptsatzkonjugation": "main-clause",
    "regelmäßig": "regular",
    "untrennbar": "inseparable",
    "trennbar": "separable",
    # Vorlage:Deutsch Nachname Übersicht
    "Singular m": ["singular", "masculine"],
    "Singular f": ["singular", "feminine"],
    # Vorlage:Deklinationsseite Numerale
    "bestimmt": "definite",
    "unbestimmt": "indefinite",
    "Unbestimmt": "indefinite",
    "mit Possessivpronomen": ["possessive", "pronoun"],
    # Template:Kroatisch Verb Übersicht
    "Partizip Präteritum Aktiv": ["past", "participle", "active"],
    # Vorlage:Bulgarisch Substantiv Übersicht f1
    "Singular bestimmt": ["singular", "definite"],
    "Plural bestimmt": ["plural", "definite"],
    # Vorlage:Schwedisch Verb Übersicht
    "Partizip Präsens": ["present", "participle"],
    # Template:Mazedonisch Substantiv Übersicht
    "Distalg": "distal",
    "Proximal": "proximal",
    "Zählform": "count-form",
}

GRAMMATICAL_TAGS = {
    **K_TEMPLATE_TAGS,
    **GENDER_TAGS,
    **NUMBER_TAGS,
    **CASE_TAGS,
    **COMPARISON_TAGS,
    **DECLENSION_TAGS,
    **OTHER_TAGS,
    **TENSE_TAGS,
    **MOOD_TAGS,
    **VERB_FORM_TAGS,
    **VOICE_TAGS,
    **PERSON_TAGS,
    **INFLECTION_TABLE_TAGS,
}

K_TEMPLATE_TOPICS = {
    "Biologie": "biology",
    "Linguistik": "linguistics",
    "Wortbildung": "morphology",
    "Behörde": "government",
    "Astronomie": "astronomy",
    "Immobilienbranche": "real-estate",
    "Kunst": "arts",
    "Informatik": "computing",
    "Nautik": "nautical",
    "Sport": "sports",
    "Schuhwerk": "footwear",
    "Textilien": "textiles",
    "Zahlungsmittel": "payment-method",
    "Ökologie": "ecology",
    "Internet": "Internet",
    "Religion": "religion",
    "Militärsprache": "military",
    "Systematik": "systematics",
    "Zoologie": "zoology",
    "Seefahrt": "seafaring",
    "Soldatensprache": {"topic": "military", "tag": "slang"},
    "Botanik": "botany",
    "Marine": "navy",
    "Informationstechnologie": "computing",
    "Betriebswirtschaftslehre": "business",
    "Recht": "law",
    "Elektronik": "electronics",
    "Emotion": "emotion",
    "Mathematik": "mathematics",
    "Bürgerliches Recht": "civil-Law",
    "Militär": "military",
    "Politik": "politics",
    "Werkzeug": "tools",
    "Medizin": "medicine",
    "Ornithologie": "ornithology",
    "Technik": "technology",
    "Waffentechnik": "weaponry",
    "Anatomie": "anatomy",
    "Fußball": "football",
    "Kartenspiel": "card-games",
    "Theoretische Informatik": "computing",
    "militärisch": "military",
    "Taxonomie": "taxonomy",
    "Chemie": "chemistry",
    "Alchimie": "alchemy",
    "Pharmazie": "medicine",
    "Wirtschaft": "economics",
    "wissenschaftlich": "scientific",
    "Gastronomie": "food",
    "Architektur": "architecture",
    "Geologie": "geology",
    "Philosophie": "philosophy",
    "Psychologie": "psychology",
    "Landwirtschaft": "agriculture",
    "Literatur": "literature",
    "Weinbau": "viticulture",
    "Meteorologie": "meteorology",
    "Kleidung": "clothing",
    "Bauwesen": "construction",
    "Geschichte": "history",
    "Christentum": "Christianity",
    "Mythologie": "mythology",
    "Grammatik": "grammar",
    "Elektrotechnik": "electrical-engineering",
}


def translate_raw_tags(data: WordEntry) -> None:
    raw_tags = []
    for raw_tag in data.raw_tags:
        if raw_tag in GRAMMATICAL_TAGS:
            tag = GRAMMATICAL_TAGS[raw_tag]
            if isinstance(tag, str) and tag not in data.tags:
                data.tags.append(tag)
            elif isinstance(tag, list):
                for t in tag:
                    if t not in data.tags:
                        data.tags.append(t)
        elif raw_tag in K_TEMPLATE_TOPICS and hasattr(data, "topics"):
            topic = K_TEMPLATE_TOPICS[raw_tag]
            if isinstance(topic, str) and topic not in data.topics:
                data.topics.append(topic)
            elif isinstance(topic, dict) and topic["topic"] not in data.topics:
                data.topics.append(topic["topic"])
                if topic["tag"] not in data.tags:
                    data.tags.append(topic["tag"])
        else:
            raw_tags.append(raw_tag)
    data.raw_tags = raw_tags
