import re
from dataclasses import dataclass

from wikitextprocessor import NodeKind, TemplateNode, WikiNode

from ...page import clean_node
from ...wxr_context import WiktextractContext
from .flexion import parse_flexion_page
from .models import Form, WordEntry
from .tags import translate_raw_tags

# Kategorie:Wiktionary:Flexionstabelle (Deutsch)


def extract_inf_table_template(
    wxr: WiktextractContext, word_entry: WordEntry, t_node: TemplateNode
) -> None:
    if (
        "Substantiv Übersicht" in t_node.template_name
        or t_node.template_name.endswith(
            (
                "Nachname Übersicht",
                "Eigenname Übersicht",
                "Vorname Übersicht m",
                "Vorname Übersicht f",
                "Name Übersicht",
                "Pronomina-Tabelle",
                "Pronomen Übersicht",
                "adjektivisch Übersicht",
                "Substantiv Dialekt",
                "Toponym Übersicht",
            )
        )
        or re.search(r" Personalpronomen \d$", t_node.template_name)
    ):
        extract_noun_table_template(wxr, word_entry, t_node)
    elif t_node.template_name.endswith(
        ("Adjektiv Übersicht", "Adverb Übersicht")
    ):
        process_adj_table(wxr, word_entry, t_node)
    elif (
        t_node.template_name.endswith("Verb Übersicht")
        or t_node.template_name == "Kardinalzahl 2-12"
    ):
        process_verb_table(wxr, word_entry, t_node)
    elif t_node.template_name == "Deutsch Possessivpronomen":
        extract_de_pronoun_table(wxr, word_entry, t_node)


@dataclass
class RowspanHeader:
    text: str
    index: int
    span: int


def process_verb_table(
    wxr: WiktextractContext, word_entry: WordEntry, t_node: TemplateNode
) -> None:
    # Vorlage:Deutsch Verb Übersicht
    expanded_template = wxr.wtp.parse(
        wxr.wtp.node_to_wikitext(t_node), expand_all=True
    )
    table_nodes = list(expanded_template.find_child(NodeKind.TABLE))
    if len(table_nodes) == 0:
        return
    table_node = table_nodes[0]
    col_headers = []
    has_person = False
    row_headers = []
    for table_row in table_node.find_child(NodeKind.TABLE_ROW):
        col_index = 0
        header_col_index = 0
        pronouns = []
        for table_cell in table_row.find_child(
            NodeKind.TABLE_HEADER_CELL | NodeKind.TABLE_CELL
        ):
            cell_text = clean_node(wxr, None, table_cell)
            if cell_text.startswith("All other forms:"):
                for link_node in table_cell.find_child_recursively(
                    NodeKind.LINK
                ):
                    link_text = clean_node(wxr, None, link_node)
                    if link_text.startswith("Flexion:"):
                        parse_flexion_page(wxr, word_entry, link_text)
            elif table_cell.kind == NodeKind.TABLE_HEADER_CELL:
                if cell_text == "":
                    continue
                elif header_col_index == 0:
                    rowspan = int(table_cell.attrs.get("rowspan", "1"))
                    row_headers.append(RowspanHeader(cell_text, 0, rowspan))
                elif cell_text in ("Person", "Wortform"):
                    has_person = True
                else:  # new table
                    col_headers.append(cell_text)
                    has_person = False
                    pronouns.clear()
                header_col_index += 1
            elif table_cell.kind == NodeKind.TABLE_CELL:
                if (
                    "background-color: #f4f4f4"
                    in table_cell.attrs.get("style", "").lower()
                ):
                    # Template:Englisch Verb Übersicht
                    rowspan = int(table_cell.attrs.get("rowspan", "1"))
                    row_headers.append(RowspanHeader(cell_text, 0, rowspan))
                    continue
                elif has_person and col_index == 0:
                    if cell_text in ("Singular", "Plural"):
                        row_headers.append(RowspanHeader(cell_text, 0, 1))
                    else:
                        pronouns = list(
                            filter(None, map(str.strip, cell_text.split(",")))
                        )
                else:
                    for cell_line in cell_text.splitlines():
                        for form_str in map(str.strip, cell_line.split(",")):
                            if form_str in ["", "—"]:
                                continue
                            elif form_str.startswith("Flexion:"):
                                parse_flexion_page(wxr, word_entry, form_str)
                                continue
                            form = Form(form=form_str, pronouns=pronouns)
                            if col_index < len(col_headers):
                                form.raw_tags.append(col_headers[col_index])
                            for row_header in row_headers:
                                form.raw_tags.append(row_header.text)
                            translate_raw_tags(form)
                            word_entry.forms.append(form)
                col_index += 1

        new_row_headers = []
        for row_header in row_headers:
            if row_header.span > 1:
                row_header.span -= 1
                new_row_headers.append(row_header)
        row_headers = new_row_headers


def extract_noun_table_template(
    wxr: WiktextractContext, word_entry: WordEntry, t_node: TemplateNode
):
    # Vorlage:Deutsch Substantiv Übersicht
    from .page import extract_note_section

    expanded_template = wxr.wtp.parse(
        wxr.wtp.node_to_wikitext(t_node), expand_all=True
    )
    clean_node(wxr, word_entry, expanded_template)
    for table in expanded_template.find_child(NodeKind.TABLE):
        process_noun_table(wxr, word_entry, table, t_node.template_name)

    # Vorlage:Deutsch Nachname Übersicht
    for level_node in expanded_template.find_child(NodeKind.LEVEL4):
        section_text = clean_node(wxr, None, level_node.largs)
        if section_text.startswith("Anmerkung"):
            extract_note_section(wxr, word_entry, level_node)


def process_noun_table(
    wxr: WiktextractContext,
    word_entry: WordEntry,
    table: WikiNode,
    template_name: str,
):
    column_headers = []
    table_header = ""
    forms = []
    flexion_pages = []
    for table_row in table.find_child(NodeKind.TABLE_ROW):
        row_header = ""
        is_header_row = not table_row.contain_node(NodeKind.TABLE_CELL)
        row_has_header = table_row.contain_node(NodeKind.TABLE_HEADER_CELL)
        col_index = 0
        for table_cell in table_row.find_child(
            NodeKind.TABLE_HEADER_CELL | NodeKind.TABLE_CELL
        ):
            cell_text = clean_node(wxr, None, table_cell)
            if table_cell.kind == NodeKind.TABLE_HEADER_CELL:
                if (
                    cell_text in ["", "Kasus", "Utrum", "m", "f", "m, f"]
                    and col_index == 0
                ):
                    continue
                elif is_header_row:
                    colspan = int(table_cell.attrs.get("colspan", "1"))
                    if cell_text != "":
                        column_headers.append(
                            RowspanHeader(
                                re.sub(r"\s*\d+$", "", cell_text),
                                col_index,
                                colspan,
                            )
                        )
                    col_index += colspan
                else:
                    row_header = cell_text
            elif cell_text == "":
                continue
            elif not row_has_header:
                # Vorlage:Deutsch adjektivisch Übersicht
                table_header = cell_text
                column_headers.clear()
                for link_node in table_cell.find_child(NodeKind.LINK):
                    link_text = clean_node(wxr, None, link_node)
                    if link_text.startswith("Flexion:"):
                        flexion_pages.append(link_text)
            else:
                for form_text in cell_text.splitlines():
                    form_text = form_text.strip()
                    if form_text.startswith("(") and form_text.endswith(")"):
                        form_text = form_text.strip("() ")
                    if form_text in ["—", "–", "-", "", "?"]:
                        continue
                    form = Form(form=form_text)
                    if table_header != "":
                        form.raw_tags.append(table_header)
                    if len(row_header) > 0:
                        form.raw_tags.append(row_header)
                    for col_header in column_headers:
                        if (
                            col_header.text not in ("", "—")
                            and col_index >= col_header.index
                            and col_index < col_header.index + col_header.span
                        ):
                            form.raw_tags.append(col_header.text)
                    translate_raw_tags(form)
                    forms.append(form)
                col_index += 1

    if template_name in (
        "Deutsch Substantiv Übersicht",
        "Deutsch Vorname Übersicht m",
        "Deutsch Vorname Übersicht f",
    ):
        forms = separate_de_article(wxr, forms)
    word_entry.forms.extend(forms)
    for flexion_page in flexion_pages:
        parse_flexion_page(wxr, word_entry, flexion_page)


def process_adj_table(
    wxr: WiktextractContext, word_entry: WordEntry, t_node: TemplateNode
) -> None:
    # Vorlage:Deutsch Adjektiv Übersicht
    expanded_template = wxr.wtp.parse(
        wxr.wtp.node_to_wikitext(t_node), expand_all=True
    )
    table_nodes = list(expanded_template.find_child(NodeKind.TABLE))
    if len(table_nodes) == 0:
        return
    table_node = table_nodes[0]
    column_headers = []
    for table_row in table_node.find_child(NodeKind.TABLE_ROW):
        for col_index, table_cell in enumerate(
            table_row.find_child(
                NodeKind.TABLE_HEADER_CELL | NodeKind.TABLE_CELL
            )
        ):
            cell_text = clean_node(wxr, None, table_cell)
            # because {{int:}} magic word is not implemented
            # template "Textbaustein-Intl" expands to English words
            if cell_text.startswith("All other forms:"):
                for link_node in table_cell.find_child(NodeKind.LINK):
                    parse_flexion_page(
                        wxr, word_entry, clean_node(wxr, None, link_node)
                    )
            elif table_cell.kind == NodeKind.TABLE_HEADER_CELL:
                column_headers.append(cell_text)
            else:
                for form_text in cell_text.splitlines():
                    if form_text in ("—", "", "?"):
                        continue
                    form = Form(form=form_text)
                    if col_index < len(column_headers):
                        form.raw_tags.append(column_headers[col_index])
                    translate_raw_tags(form)
                    word_entry.forms.append(form)


def extract_de_pronoun_table(
    wxr: WiktextractContext, word_entry: WordEntry, t_node: TemplateNode
) -> None:
    # Vorlage:Deutsch Possessivpronomen
    expanded_template = wxr.wtp.parse(
        wxr.wtp.node_to_wikitext(t_node), expand_all=True
    )
    table_nodes = list(expanded_template.find_child(NodeKind.TABLE))
    if len(table_nodes) == 0:
        return
    table_node = table_nodes[0]
    col_headers = []
    table_header = ""
    for row in table_node.find_child(NodeKind.TABLE_ROW):
        row_header = ""
        row_has_data = row.contain_node(NodeKind.TABLE_CELL)
        col_index = 0
        article = ""
        for cell in row.find_child(
            NodeKind.TABLE_HEADER_CELL | NodeKind.TABLE_CELL
        ):
            cell_text = clean_node(wxr, None, cell)
            if cell.kind == NodeKind.TABLE_HEADER_CELL:
                if cell_text == "":
                    continue
                elif row_has_data:
                    row_header = cell_text
                elif len(list(row.find_child(NodeKind.TABLE_HEADER_CELL))) == 1:
                    table_header = cell_text
                    col_headers.clear()  # new table
                    article = ""
                else:
                    colspan = 1
                    colspan_str = cell.attrs.get("colspan", "1")
                    if re.fullmatch(r"\d+", colspan_str):
                        colspan = int(colspan_str)
                    if cell_text != "—":
                        col_headers.append(
                            RowspanHeader(cell_text, col_index, colspan)
                        )
                    col_index += colspan
            elif cell.kind == NodeKind.TABLE_CELL:
                if col_index % 2 == 0:
                    if cell_text != "—":
                        article = cell_text
                else:
                    form = Form(form=cell_text, article=article)
                    if table_header != "":
                        form.raw_tags.append(table_header)
                    if row_header != "":
                        form.raw_tags.append(row_header)
                    for header in col_headers:
                        if (
                            col_index >= header.index
                            and col_index < header.index + header.span
                            and header.text != "Wortform"
                        ):
                            form.raw_tags.append(header.text)
                    translate_raw_tags(form)
                    if form.form not in ["", "—"]:
                        word_entry.forms.append(form)
                    article = ""
                col_index += 1


def separate_de_article(
    wxr: WiktextractContext, forms: list[Form]
) -> list[Form]:
    # https://en.wikipedia.org/wiki/German_articles
    # https://de.wiktionary.org/wiki/Vorlage:Deutsch_Substantiv_Übersicht
    # https://de.wiktionary.org/wiki/Vorlage:Deutsch_Vorname_Übersicht_m
    # * May contain parens around the article
    new_forms = []
    for form in forms:
        m = re.match(r"\(?(der|die|das|den|dem|des)\)?\s+", form.form)
        if m is not None:
            form.form = form.form[m.end() :]
            form.article = m.group(1)
        if form.form not in ["", "—"]:
            new_forms.append(form)
    return new_forms
