from dataclasses import dataclass

from wikitextprocessor import HTMLNode, NodeKind, TemplateNode, WikiNode

from ...page import clean_node
from ...wxr_context import WiktextractContext
from .models import Form, WordEntry
from .tags import translate_raw_tags


def extract_conjugation_section(
    wxr: WiktextractContext, page_data: list[WordEntry], level_node: WikiNode
) -> None:
    forms = []
    cats = []
    for t_node in level_node.find_child(NodeKind.TEMPLATE):
        if t_node.template_name in ["es.v", "en.v", "de.v", "pl.v"]:
            new_forms, new_cats = process_es_v_template(wxr, t_node)
            forms.extend(new_forms)
            cats.extend(new_cats)

    for data in page_data:
        if (
            data.lang_code == page_data[-1].lang_code
            and data.etymology_texts == page_data[-1].etymology_texts
            and data.pos == "verb"  # should be fixed on Wiktionary
        ):
            data.forms.extend(forms)
            data.categories.extend(cats)


@dataclass
class SpanHeader:
    text: str
    index: int
    span: int


# https://en.wikipedia.org/wiki/Spanish_pronouns
PRONOUN_TAGS = {
    "yo": ["first-person", "singular"],
    "que yo": ["first-person", "singular"],
    "tú": ["second-person", "singular"],
    "que tú": ["second-person", "singular"],
    "(tú)": ["second-person", "singular"],
    "vos": ["second-person", "singular", "vos-form"],
    "que vos": ["second-person", "singular", "vos-form"],
    "(vos)": ["second-person", "singular", "vos-form"],
    "él, ella, usted": ["third-person", "singular"],
    "que él, que ella, que usted": ["third-person", "singular"],
    "(usted)": ["third-person", "singular"],
    "nosotros": ["first-person", "plural"],
    "que nosotros": ["first-person", "plural"],
    "(nosotros)": ["first-person", "plural"],
    "vosotros": ["second-person", "plural"],
    "que vosotros": ["second-person", "plural"],
    "(vosotros)": ["second-person", "plural"],
    "ustedes, ellos": ["third-person", "plural"],
    "que ustedes, que ellos": ["third-person", "plural"],
    "(ustedes)": ["third-person", "plural"],
    # Template:en.v
    "I": ["first-person"],
    "you": ["second-person"],
    "(you)": ["second-person"],
    "he, she, it": ["third-person", "singular"],
    "we, you, they": ["third-person", "plural"],
    "(we)": ["third-person", "plural"],
    # Template:de.v
    "ich": ["first-person", "singular"],
    "du": ["second-person", "singular"],
    "er, sie, es": ["third-person", "singular"],
    "wir": ["first-person", "plural"],
    "ihr": ["second-person", "plural"],
    "sie": ["third-person", "plural"],
    "(du)": ["second-person", "singular"],
    "(wir)": ["first-person", "plural"],
    "(ihr)": ["second-person", "plural"],
    "(Sie)": ["third-person", "plural"],
    # Template:pl.v
    "ja": ["first-person", "singular"],
    "ty": ["second-person", "singular"],
    "on, ona, ono": ["third-person", "singular"],
    "my": ["first-person", "plural"],
    "wy": ["second-person", "plural"],
    "oni, one": ["third-person", "plural"],
    "(ty)": ["second-person", "singular"],
    "(my)": ["first-person", "plural"],
    "(wy)": ["second-person", "plural"],
}


def process_es_v_template(
    wxr: WiktextractContext, template_node: TemplateNode
) -> tuple[list[Form], list[str]]:
    # https://es.wiktionary.org/wiki/Plantilla:es.v
    forms = []
    cats = {}
    expanded_node = wxr.wtp.parse(
        wxr.wtp.node_to_wikitext(template_node), expand_all=True
    )
    clean_node(wxr, cats, expanded_node)
    table_nodes = list(expanded_node.find_child_recursively(NodeKind.TABLE))
    if len(table_nodes) == 0:
        return [], []
    table_node = table_nodes[0]
    col_headers = []
    for row in table_node.find_child(NodeKind.TABLE_ROW):
        row_header = ""
        single_cell = len(list(row.filter_empty_str_child())) == 1
        all_header_row = row.contain_node(
            NodeKind.TABLE_HEADER_CELL
        ) and not row.contain_node(NodeKind.TABLE_CELL)
        if not all_header_row and single_cell:
            continue  # ignore end notes
        if all_header_row and single_cell:
            col_headers.clear()  # new table

        col_index = 0
        is_archaic_row = False
        for cell in row.find_child(
            NodeKind.TABLE_HEADER_CELL | NodeKind.TABLE_CELL
        ):
            cell_text = clean_node(wxr, None, cell)
            if cell_text == "":
                continue
            if cell.kind == NodeKind.TABLE_HEADER_CELL:
                if all_header_row:
                    colspan = int(cell.attrs.get("colspan", "1"))
                    col_headers.append(
                        SpanHeader(
                            cell_text.removeprefix("Modo ").strip(),
                            col_index,
                            colspan,
                        )
                    )
                    col_index += colspan
                else:
                    is_archaic_row = cell_text.endswith("^†")
                    row_header = cell_text.removesuffix("^†").strip()
            else:
                cell_nodes = []
                found_sup = []
                for node in cell.children:
                    if isinstance(node, HTMLNode) and node.tag == "sup":
                        sup_tag = clean_node(wxr, None, node.children)
                        if sup_tag != "":
                            found_sup.append(sup_tag)
                    elif not (
                        isinstance(node, HTMLNode)
                        and "movil" in node.attrs.get("class", "")
                    ):
                        if len(found_sup) > 0:
                            forms.extend(
                                process_es_v_cell(
                                    wxr,
                                    cell_nodes,
                                    col_index,
                                    col_headers,
                                    row_header,
                                    is_archaic_row,
                                )
                            )
                            if len(forms) > 0:
                                forms[-1].raw_tags.extend(found_sup)
                                translate_raw_tags(forms[-1])
                            found_sup.clear()
                            cell_nodes.clear()
                        cell_nodes.append(node)  # hidden HTML tag
                if len(cell_nodes) > 0:
                    forms.extend(
                        process_es_v_cell(
                            wxr,
                            cell_nodes,
                            col_index,
                            col_headers,
                            row_header,
                            is_archaic_row,
                        )
                    )
                    if len(found_sup) > 0 and len(forms) > 0:
                        forms[-1].raw_tags.extend(found_sup)
                        translate_raw_tags(forms[-1])
                    found_sup.clear()
                    cell_nodes.clear()
                col_index += 1
    return forms, cats.get("categories", [])


def process_es_v_cell(
    wxr: WiktextractContext,
    cell_nodes: list[WikiNode | str],
    col_index: int,
    col_headers: list[SpanHeader],
    row_header: str,
    is_archaic: bool,
) -> list[Form]:
    forms = []
    for form_str in clean_node(wxr, None, cell_nodes, no_strip=True).split(","):
        form_str = form_str.strip()
        if not form_str:
            continue
        form = Form(form=form_str)
        for col_head in col_headers:
            if (
                col_index >= col_head.index
                and col_index < col_head.index + col_head.span
            ):
                form.raw_tags.append(col_head.text)
                form.tags.extend(PRONOUN_TAGS.get(col_head.text, []))
        if row_header != "":
            form.raw_tags.append(row_header)
        if is_archaic:
            form.tags.append("archaic")
        if form.form not in ["", "―", wxr.wtp.title]:
            translate_raw_tags(form)
            forms.append(form)
    return forms
