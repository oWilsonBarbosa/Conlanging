import re
import unicodedata
from typing import Generator, TypeAlias

from wikitextprocessor import LevelNode, WikiNode

from wiktextract.page import clean_node
from wiktextract.wxr_context import WiktextractContext

from .models import Form, WordEntry
from .section_titles import (
    POS_HEADINGS,
    POS_HEADINGS_RE,
    SUBSECTION_HEADINGS,
    SUBSECTIONS_RE,
    Heading,
    POSName,
    Tags,
)
from .text_utils import normalized_int

# Ignorable templates that generate panels to the side, like
# Template:Wikipedia, or other meta-info like Template:see.
# Called 'panel templates' because they often generate panels.
PANEL_TEMPLATES: set[str] = set(
    [
        "interwiktionary",
        "stub",
        "wik",
        "wikipedia",
        "Wikipedia",
        "wikispecies",
        "wikiquote",
        "Wikiquote",
        "improve",
    ]
)

# Template name prefixes used for language-specific panel templates (i.e.,
# templates that create side boxes or notice boxes or that should generally
# be ignored).
# PANEL_PREFIXES: set[str] = set()

# Additional templates to be expanded in the pre-expand phase
# XXX nothing here yet, add as needed if some template turns out to be
# problematic when unexpanded.
ADDITIONAL_EXPAND_TEMPLATES: set[str] = set()

# Names of templates used in etymology sections whose parameters we want
# to store in `etymology_templates`.
ETYMOLOGY_TEMPLATES: set[str] = set()

GREEK_LANGCODES = set(
    (
        "el",
        "grc",
        "el2",
        "el-crt",
        "el-cyp",
        "gkm",
        "gkm-cyp",
        "gkm-crt",
        "gmy",
        "gmy2",
        "grc-dor",
        "grc-ion",
        "grc-koi",
        "grk",
        "grk-ita",
        "grk-pro",
        "kath",
        "pnt",
        "pregrc",
        "tsd",
        "xme-old",
        "xmk",
    )
)


Title: TypeAlias = str
SectionName: TypeAlias = str  # The keys of SUBSECTION_HEADINGS
POSReturns: TypeAlias = list[
    tuple[POSName, Title, Tags, int, WikiNode, WordEntry]
]


def find_sections(
    wxr: WiktextractContext,
    nodes: list[WikiNode] | list[LevelNode],
) -> Generator[
    tuple[Heading, POSName | SectionName, Title, Tags, int, WikiNode],
    None,
    None,
]:
    """In practice, only called when we expect heading_type to be either
    Heading.POS or Heading.Pron.

    Heading.POS guarantees that pos_or_section is a POSName.
    Heading.Pron guarantees that pos_or_section is a SectionName, and, looking
    at SUBSECTION_HEADINGS, either: "pronunciation" or "προφορά"
    """
    for node in nodes:
        heading_title = clean_node(wxr, None, node.largs[0]).lower().strip()

        heading_type, pos_or_section, tags, num, ok = parse_lower_heading(
            wxr, heading_title
        )

        if num > 0:
            wxr.wtp.wiki_notice(
                f"Sub-sub-section is numbered: {heading_title}, {num=}",
                sortid="page/find_pos_sections_1",
            )
        yield heading_type, pos_or_section, heading_title, tags, num, node


def parse_lower_heading(
    wxr: WiktextractContext, heading: str
) -> tuple[Heading, POSName | SectionName, Tags, int, bool]:
    """Determine if a heading is for a part of speech or other subsection.
    Returns heading type enum, POS name or string data, list of tags and a
    success bool.
    """
    if m := POS_HEADINGS_RE.match(heading):
        heading_type, pos, tags, num, ok = parse_pos_heading(wxr, heading, m)
        if ok:
            return heading_type, pos, tags, num, True

    if m := SUBSECTIONS_RE.match(heading):
        heading_type, section, tags, num, ok = parse_section_heading(
            wxr, heading, m
        )
        if ok:
            return heading_type, section, tags, num, True

    return Heading.Err, "", [], -1, False


def parse_pos_heading(
    wxr: WiktextractContext, heading: str, m: re.Match[str]
) -> tuple[Heading, POSName, Tags, int, bool]:
    pos_str = m.group(1)
    rest = m.group(2)
    post_number = -1
    if rest:
        # logger.info(f"POS REST: '{rest}'")
        if rest.strip().isdigit():
            post_number = normalized_int(rest.strip())
            # logger.info(f"POST_NUMBER {post_number}")
    pos_data = POS_HEADINGS[pos_str]
    return (
        Heading.POS,
        pos_data["pos"],
        pos_data.get("tags", []),
        post_number,
        True,
    )


def parse_section_heading(
    wxr: WiktextractContext, heading: str, m: re.Match[str]
) -> tuple[Heading, SectionName, Tags, int, bool]:
    subsection_str = m.group(1)
    rest = m.group(2)
    post_number = -1
    if rest:
        # logger.info(f"SUBSECTION REST: '{rest}'")
        if rest.strip().isdigit():
            post_number = normalized_int(rest.strip())
            # logger.info(f"POST_NUMBER {post_number}")
    section_data = SUBSECTION_HEADINGS[subsection_str]
    return (
        section_data["type"],
        subsection_str,
        section_data.get("tags", []),
        post_number,
        True,
    )


# https://stackoverflow.com/a/518232
def strip_accents(accented: str) -> str:
    return "".join(
        c
        for c in unicodedata.normalize("NFD", accented)
        if unicodedata.category(c) != "Mn"
    )


def remove_duplicate_forms(
    wxr: WiktextractContext, forms: list[Form]
) -> list[Form]:
    """Check for identical `forms` and remove duplicates."""
    if not forms:
        return []
    new_forms = []
    for i, form in enumerate(forms):
        for comp in forms[i + 1 :]:
            if (
                form.form == comp.form
                and form.tags == comp.tags
                and form.raw_tags == comp.raw_tags
            ):
                break
                # basically "continue" for the outer for block in this case,
                # but this will not trigger the following else-block
        else:
            # No duplicates found in for loop (exited without breaking)
            new_forms.append(form)
    if len(forms) > len(new_forms):
        # wxr.wtp.debug("Found duplicate forms", sortid="simple/pos/32")
        return new_forms
    return forms


def get_stem(word: str) -> str:
    """Get the stem from a Greek adjective or participle."""
    vowels = "αειουηω"
    vowel_digraphs = ["αι", "ει", "οι", "ου", "υι"]
    idx = len(word)
    nword = strip_accents(word)  # normalized
    # 1. Consume every consonant until we find a vowel
    while idx > 0 and nword[idx - 1] not in vowels:
        idx -= 1
    # 2. Consume the vowel/digraph
    if idx > 2 and nword[idx - 2 : idx] in vowel_digraphs:
        idx -= 2
    elif idx > 1 and nword[idx - 1] in vowels:
        idx -= 1
    return word[:idx]


def expand_suffix_forms(forms: list[Form]) -> list[Form]:
    """Expand headword suffix endings for Greek adjectives or participles.

    Assume that forms are given in parsed order. That is: masc/fem/neut

    Reference:
    * https://el.wiktionary.org/wiki/Παράρτημα:Επίθετα_και_μετοχές_(νέα_ελληνικά)
    * https://el.wiktionary.org/wiki/άμεσος (adjective)
    * https://el.wiktionary.org/wiki/αρσενικός (adjective)
    * https://el.wiktionary.org/wiki/αναμμένος (participle)
    """
    assert len(forms) == 3
    base, *others = forms

    # The first form should NOT start with an hyphen, and the other two should.
    # cf. άμεσος, -η, -ο
    if base.form.startswith("-") or not all(
        f.form.startswith("-") for f in others
    ):
        return forms

    word = base.form
    stem = get_stem(word)

    associated_tags = [
        ["masculine", "singular", "nominative"],
        ["feminine", "singular", "nominative"],
        ["neuter", "singular", "nominative"],
    ]

    expanded_forms: list[Form] = []
    new_form = base.model_copy(deep=True)
    new_form.tags.extend(associated_tags[0])
    expanded_forms.append(new_form)

    for idx, form in enumerate(others, 1):
        for ending in form.form.replace("-", "").split("/"):
            new_form = form.model_copy(deep=True)
            new_form.form = f"{stem}{ending}"
            new_form.tags.extend(associated_tags[idx])
            expanded_forms.append(new_form)

    return expanded_forms
